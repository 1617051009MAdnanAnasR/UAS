package com.example.anas.im4.Jadwal;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.anas.im4.R;

import java.util.List;

public class JadwalAdapter extends RecyclerView.Adapter<JadwalAdapter.Holder>{
    private List<JadwalModel> mListData;
    private Context mContext;

    public JadwalAdapter(List<JadwalModel> mListData, Context mContext) {
        this.mListData = mListData;
        this.mContext = mContext;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.activity_adapter_jadwal, null);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        JadwalModel model = mListData.get(position);

        holder.tvjam.setText(model.getjam());
        holder.tvhome.setText(model.gethome());
        holder.tvaway.setText(model.getaway());
        holder.tvtanggal.setText(model.gettanggal());
        Glide.with(mContext).load(model.getLogo_home()).into(holder.ivlogo_home);
        Glide.with(mContext).load(model.getLogo_away()).into(holder.ivlogo_away);
    }

    @Override
    public int getItemCount() {
        return mListData.size();
    }

    public static class Holder extends RecyclerView.ViewHolder {

        public TextView tvhome;
        public TextView tvaway;
        public TextView tvtanggal;
        public TextView tvjam;
        public ImageView ivlogo_home;
        public ImageView ivlogo_away;


        public Holder(View itemView) {
            super(itemView);

            tvhome = (TextView) itemView.findViewById(R.id.homeNameTv);
            tvaway = (TextView) itemView.findViewById(R.id.awayNameTv);
            tvtanggal = (TextView) itemView.findViewById(R.id.dateScheduleTv);
            tvjam = (TextView) itemView.findViewById(R.id.jams);
            ivlogo_home = (ImageView) itemView.findViewById(R.id.logo_home);
            ivlogo_away = (ImageView) itemView.findViewById(R.id.logo_away);

        }
    }
}
