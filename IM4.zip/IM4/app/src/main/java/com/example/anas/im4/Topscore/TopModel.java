package com.example.anas.im4.Topscore;

public class TopModel {
    private String logo;
    private String nama;


    public TopModel(String logo, String nama) {
        this.logo = logo;
        this.nama = nama;
    }

    public TopModel() {
    }

    public String getlogo() {
        return logo;
    }

    public void setlogo(String logo) {
        this.logo = logo;
    }

    public String getnama() {
        return nama;
    }

    public void setnama(String nama) {
        this.nama = nama;
    }
}
