package com.example.anas.im4.Klasemen;

public class KlasemenModel {
    private String club;
    private String play;
    private String win;
    private String draw;
    private String lose;
    private String goals;
    private String poin;

    public KlasemenModel(String club,String play, String win, String draw, String lose, String goals,String poin) {
        this.club = club;
        this.play = play;
        this.win = win;
        this.draw = draw;
        this.lose = lose;
        this.goals = goals;
        this.poin = poin;
    }

    public KlasemenModel() {
    }

    public String getclub() {
        return club;
    }

    public void setclub(String club) {
        this.club = club;
    }

    public String getplay() {
        return play;
    }

    public void setplay(String play) {
        this.play = play;
    }

    public String getwin() {
        return win;
    }

    public void setwin(String win) {
        this.win = win;
    }

    public String getdraw() {
        return draw;
    }

    public void setdraw(String draw) {
        this.draw = draw;
    }

    public String getlose() {
        return lose;
    }

    public void setlose(String lose) {
        this.lose = lose;
    }

    public String getgoals() {
        return goals;
    }

    public void setgoals(String goals ) {
        this.goals = goals;
    }

    public String getpoin() {
        return poin;
    }

    public void setpoin(String poin) {
        this.poin = poin;
    }


}
