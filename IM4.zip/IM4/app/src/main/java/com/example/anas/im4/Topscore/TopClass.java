package com.example.anas.im4.Topscore;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.anas.im4.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TopClass extends AppCompatActivity {

    private String urlData = "https://www.thesportsdb.com/api/v1/json/1/lookup_all_teams.php?id=4328";

    private RecyclerView recyclerViewHasil;
    private TopAdapter mAdapter;
    private ProgressDialog mProgressDialog;
    private List<TopModel> mListData;
    //private CardView all;
   // private DBDataSource db;
    //private boolean favorite;
    //private ImageView buttonf;
    //private Integer id;
    //private String code;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_class);

        recyclerViewHasil = (RecyclerView) findViewById(R.id.recyclerview);

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Loading ...");
        mProgressDialog.show();

        mListData = new ArrayList<>();

        getDataVolley();

        //db = new DBDataSource(this);
        //db.open();

        //favorite = db.isFavorite(Integer.valueOf(id));

        //buttonf = (ImageView) findViewById(R.id.button_favorite);
        //if (favorite) {
            //buttonf.setImageResource(R.drawable.ic_favorite);
        //}
        //else {
            //buttonf.setImageResource(R.drawable.ic_favorite_border);
        //}
        //buttonf.setOnClickListener(new Button.OnClickListener() {
            //public void onClick(View v) {
                //Log.i("CEK", String.valueOf(favorite));
                //if (favorite) {
                    //buttonf.setImageResource(R.drawable.ic_favorite_border);
                    //db.deleteTeam(Integer.valueOf(id));
                    //favorite = false;
                //}
                //else {
                    //buttonf.setImageResource(R.drawable.ic_favorite);
                    //favorite = true;

                    //if (db.insertTeam(String.valueOf(id),code)) {
                    //}
                    //else {

                    //}
                //}
            //}
        //});

    }

    private void getDataVolley(){

        final StringRequest request = new StringRequest(Request.Method.GET, urlData,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mProgressDialog.dismiss();
                        iniData(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void iniData(String response){
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONArray jsonArray = jsonObject.getJSONArray("teams");

            for(int i=0; i<jsonArray.length(); i++){
                JSONObject objectHasil = jsonArray.getJSONObject(i);
                String logo = objectHasil.getString("strTeamBadge");
                String nama = objectHasil.getString("strTeam");


                TopModel hasilModel = new TopModel();
                hasilModel.setlogo(logo);
                hasilModel.setnama(nama);

                //                hasilModel.setLogo_home(id_home);


                mListData.add(hasilModel);

                mAdapter = new TopAdapter(mListData, TopClass.this);
                mAdapter.notifyDataSetChanged();
                recyclerViewHasil.setLayoutManager(new LinearLayoutManager(TopClass.this));
                recyclerViewHasil.setItemAnimator(new DefaultItemAnimator());
                recyclerViewHasil.setAdapter(mAdapter);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
