package com.example.anas.im4.Setting;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.anas.im4.R;

import java.util.Locale;

public class SetClass extends AppCompatActivity  implements View.OnClickListener{

    private Button btnChangeLanguage;
    private TextView tvCurrentLanguage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_class);

        tvCurrentLanguage = (TextView) findViewById(R.id.textview_current_language);
        btnChangeLanguage = (Button) findViewById(R.id.btn_change_language);

        tvCurrentLanguage.setText(getString(R.string.bahasa) + "  " + Locale.getDefault().getDisplayLanguage());

        btnChangeLanguage.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v== btnChangeLanguage){
            Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(intent);
        }
    }
}