package com.example.anas.im4.Klasemen;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.anas.im4.R;

import java.util.List;

public class KlasemenAdapter extends RecyclerView.Adapter<KlasemenAdapter.Holder>{
    private List<KlasemenModel> mListData;
    private Context mContext;

    public KlasemenAdapter(List<KlasemenModel> mListData, Context mContext) {
        this.mListData = mListData;
        this.mContext = mContext;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.activity_adapter_klasemen, null);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        KlasemenModel model = mListData.get(position);

        holder.tvclub.setText(model.getclub());
        holder.tvplay.setText(model.getplay());
        holder.tvwin.setText(model.getwin());
        holder.tvdraw.setText(model.getdraw());
        holder.tvlose.setText(model.getlose());
        holder.tvgoals.setText(model.getgoals());
        holder.tvpoin.setText(model.getpoin());

    }

    @Override
    public int getItemCount() {
        return mListData.size();
    }

    public static class Holder extends RecyclerView.ViewHolder {

        public TextView tvclub;
        public TextView tvplay;
        public TextView tvwin;
        public TextView tvdraw;
        public TextView tvlose;
        public TextView tvgoals;
        public TextView tvpoin;



        public Holder(View itemView) {
            super(itemView);

            tvclub = (TextView) itemView.findViewById(R.id.club);
            tvplay = (TextView) itemView.findViewById(R.id.play);
            tvwin = (TextView) itemView.findViewById(R.id.win);
            tvdraw = (TextView) itemView.findViewById(R.id.draw);
            tvlose = (TextView) itemView.findViewById(R.id.lose);
            tvgoals = (TextView) itemView.findViewById(R.id.goals);
            tvpoin = (TextView) itemView.findViewById(R.id.poin);


        }
    }
}
