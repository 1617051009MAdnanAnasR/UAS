package com.example.anas.im4.Jadwal;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.anas.im4.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JadwalClass extends AppCompatActivity {

    private String urlData = "https://www.thesportsdb.com/api/v1/json/1/eventsnextleague.php?id=4328";

    private RecyclerView recyclerViewHasil;
    private JadwalAdapter mAdapter;
    private ProgressDialog mProgressDialog;
    private List<JadwalModel> mListData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_class);

        recyclerViewHasil = (RecyclerView) findViewById(R.id.recyclerview);

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Loading ...");
        mProgressDialog.show();

        mListData = new ArrayList<>();

        getDataVolley();
    }

    private void getDataVolley(){

        final StringRequest request = new StringRequest(Request.Method.GET, urlData,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mProgressDialog.dismiss();
                        iniData(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void iniData(String response){
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONArray jsonArray = jsonObject.getJSONArray("events");

            for(int i=0; i<jsonArray.length(); i++){
                JSONObject objectHasil = jsonArray.getJSONObject(i);
                String jam = objectHasil.getString("strTime");
                String tanggal = objectHasil.getString("strDate");
                String home = objectHasil.getString("strHomeTeam");
                String away = objectHasil.getString("strAwayTeam");
                String id_home = objectHasil.getString("idHomeTeam");
//                String id_away = objectHasil.getString("idAwayTeam");

                JadwalModel hasilModel = new JadwalModel();
                hasilModel.setjam(jam);
                hasilModel.settanggal(tanggal);
                hasilModel.sethome(home);
                hasilModel.setaway(away);
                //                hasilModel.setLogo_home(id_home);

                String away_id = id_home.concat("aja");
                String id = "133613aja";
                if(away_id == id) {
                    String logo_away = "https://www.thesportsdb.com/images/media/team/badge/a1af2i1557005128.png";
                    hasilModel.setLogo_away(logo_away);
                }

                mListData.add(hasilModel);

                mAdapter = new JadwalAdapter(mListData, JadwalClass.this);
                mAdapter.notifyDataSetChanged();
                recyclerViewHasil.setLayoutManager(new LinearLayoutManager(JadwalClass.this));
                recyclerViewHasil.setItemAnimator(new DefaultItemAnimator());
                recyclerViewHasil.setAdapter(mAdapter);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
