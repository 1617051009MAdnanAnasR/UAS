package com.example.anas.im4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

import com.example.anas.im4.Hasil.HasilClass;
import com.example.anas.im4.Jadwal.JadwalClass;
import com.example.anas.im4.Klasemen.KlasemenClass;
import com.example.anas.im4.Setting.SetClass;
import com.example.anas.im4.Topscore.TopClass;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private CardView hasil, jadwal, klasemen, top, set;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hasil = (CardView) findViewById(R.id.hasil);
        jadwal = (CardView) findViewById(R.id.jadwal);
        klasemen = (CardView) findViewById(R.id.klasemen);
        top = (CardView) findViewById(R.id.top);
        set = (CardView) findViewById(R.id.set);

        hasil.setOnClickListener(this);
        jadwal.setOnClickListener(this);
        klasemen.setOnClickListener(this);
        top.setOnClickListener(this);
        set.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;
        switch (v.getId()) {
            case R.id.hasil: i = new Intent(this,HasilClass.class);startActivity(i);break;
            case R.id.jadwal: i = new Intent(this,JadwalClass.class);startActivity(i);break;
            case R.id.klasemen: i = new Intent(this,KlasemenClass.class);startActivity(i);break;
            case R.id.top: i = new Intent(this,TopClass.class);startActivity(i);break;
            case R.id.set: i = new Intent(this,SetClass.class);startActivity(i);break;
            default:break;
        }
    }
}
