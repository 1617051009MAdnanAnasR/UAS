package com.example.anas.im4.Topscore;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DBDataSource {
    private SQLiteDatabase database;

    private DBHelper dbHelper;

    private String[] allColumns = { DBHelper.COLUMN_ID, DBHelper.COLUMN_CODE};

    public DBDataSource(Context context)
    {
        dbHelper = new DBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean insertTeam(String id, String code) {
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_ID, id);
        values.put(DBHelper.COLUMN_CODE, code);
        long insertId = database.insert(DBHelper.TABLE_NAME,null,
                values);

        if (insertId == -1) return false;
        else return true;
    }

    private Team cursorToTeam(Cursor cursor)
    {
        Team team = new Team();
        // debug LOGCAT
        team.setId(cursor.getInt(0));
        team.setCode(cursor.getString(1));

        return team;
    }

    public ArrayList<Team> getStudioMusik() {
        ArrayList<Team> daftarTeam = new ArrayList<Team>();

        Cursor cursor = database.query(DBHelper.TABLE_NAME,
                allColumns, null, null, null, null, null, null);

        // pindah ke data paling pertama
        cursor.moveToFirst();
        // jika masih ada data, masukkan data barang ke
        // daftar barang
        while (!cursor.isAfterLast()) {
            Team team = cursorToTeam(cursor);
            daftarTeam.add(team);
            cursor.moveToNext();
        }
        cursor.close();
        return daftarTeam;
    }

    public boolean isFavorite(Integer id)
    {
        Team team = new Team();
        //select query
        Cursor cursor = database.query(DBHelper.TABLE_NAME, allColumns, "id ="+id,null, null, null, null, null);
        if (cursor.getCount()>0) return true;
        else return false;
    }

    public void updateTeam(Team b)
    {
        //ambil id barang
        String strFilter = "id=" + b.getId();
        //memasukkan ke content values
        ContentValues args = new ContentValues();
        //masukkan data sesuai dengan kolom pada database
        args.put(DBHelper.COLUMN_CODE, b.getCode());

        //update query
        database.update(DBHelper.TABLE_NAME, args, strFilter, null);
    }

    public void deleteTeam(Integer id)
    {
        String strFilter = "id=" + id;
        database.delete(DBHelper.TABLE_NAME, strFilter, null);
    }
}
