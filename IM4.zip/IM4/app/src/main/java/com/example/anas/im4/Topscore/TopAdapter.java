package com.example.anas.im4.Topscore;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.anas.im4.R;

import java.util.List;

public class TopAdapter extends RecyclerView.Adapter<TopAdapter.Holder>{
    private List<TopModel> mListData;
    private Context mContext;

    public TopAdapter(List<TopModel> mListData, Context mContext) {
        this.mListData = mListData;
        this.mContext = mContext;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.activity_adapter_top, null);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        TopModel model = mListData.get(position);

        holder.tvnama.setText(model.getnama());
        Glide.with(mContext).load(model.getlogo()).into(holder.tvlogo);
    }

    @Override
    public int getItemCount() {
        return mListData.size();
    }

    public static class Holder extends RecyclerView.ViewHolder {

        public ImageView tvlogo;
        public TextView tvnama;




        public Holder(View itemView) {
            super(itemView);

            tvlogo = (ImageView) itemView.findViewById(R.id.logoclub);
            tvnama = (TextView) itemView.findViewById(R.id.namaclub);

        }
    }
}
