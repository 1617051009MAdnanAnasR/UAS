package com.example.anas.im4.Jadwal;

public class JadwalModel {
    private String jam;
    private String tanggal;
    private String home;
    private String away;
    private String logo_home;
    private String logo_away;

    public JadwalModel(String jam,String tanggal, String home, String away, String logo_home, String logo_away) {
        this.tanggal = tanggal;
        this.home = home;
        this.away = away;
        this.logo_home = logo_home;
        this.jam = jam;
    }

    public JadwalModel() {
    }

    public String getjam() {
        return jam;
    }

    public void setjam(String jam) {
        this.jam = jam;
    }

    public String gettanggal() {
        return tanggal;
    }

    public void settanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String gethome() {
        return home;
    }

    public void sethome(String home) {
        this.home = home;
    }

    public String getaway() {
        return away;
    }

    public void setaway(String away) {
        this.away = away;
    }

    public String getLogo_home() {
        return logo_home;
    }

    public void setLogo_home(String logo_home) {
        this.logo_home = logo_home;
    }

    public String getLogo_away() {
        return logo_away;
    }

    public void setLogo_away(String logo_away) {
        this.logo_away = logo_away;
    }
}
