package com.example.anas.im4.Hasil;

public class HasilModel {
    private String tanggal;
    private String home;
    private String away;
    private String home_skor;
    private String away_skor;
    private String logo_home;
    private String logo_away;

    public HasilModel(String tanggal, String home, String away, String home_skor, String away_skor, String logo_home, String logo_away) {
        this.tanggal = tanggal;
        this.home = home;
        this.away = away;
        this.home_skor = home_skor;
        this.away_skor = away_skor;
        this.logo_home = logo_home;
    }

    public HasilModel() {
    }

    public String getaway_skor() {
        return away_skor;
    }

    public void setaway_skor(String away_skor) {
        this.away_skor = away_skor;
    }

    public String gettanggal() {
        return tanggal;
    }

    public void settanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String gethome() {
        return home;
    }

    public void sethome(String home) {
        this.home = home;
    }

    public String getaway() {
        return away;
    }

    public void setaway(String away) {
        this.away = away;
    }

    public String gethome_skor() {
        return home_skor;
    }

    public void sethome_skor(String home_skor) {
        this.home_skor = home_skor;
    }

    public String getLogo_home() {
        return logo_home;
    }

    public void setLogo_home(String logo_home) {
        this.logo_home = logo_home;
    }

    public String getLogo_away() {
        return logo_away;
    }

    public void setLogo_away(String logo_away) {
        this.logo_away = logo_away;
    }
}
