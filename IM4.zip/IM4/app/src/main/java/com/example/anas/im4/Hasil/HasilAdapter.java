package com.example.anas.im4.Hasil;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.anas.im4.R;

import java.util.List;

public class HasilAdapter extends RecyclerView.Adapter<HasilAdapter.Holder>{
    private List<HasilModel> mListData;
    private Context mContext;

    public HasilAdapter(List<HasilModel> mListData, Context mContext) {
        this.mListData = mListData;
        this.mContext = mContext;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.activity_adapter_hasil, null);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        HasilModel model = mListData.get(position);

        //set data makanan
        holder.tvhome.setText(model.gethome());
        holder.tvaway.setText(model.getaway());
        holder.tvaway_skor.setText(model.getaway_skor());
        holder.tvhome_skor.setText(model.gethome_skor());
        holder.tvtanggal.setText(model.gettanggal());
        Glide.with(mContext).load(model.getLogo_home()).into(holder.ivlogo_home);
        Glide.with(mContext).load(model.getLogo_away()).into(holder.ivlogo_away);
    }

    @Override
    public int getItemCount() {
        return mListData.size();
    }

    public static class Holder extends RecyclerView.ViewHolder {

        public TextView tvhome;
        public TextView tvaway;
        public TextView tvaway_skor;
        public TextView tvhome_skor;
        public TextView tvtanggal;
        public ImageView ivlogo_home;
        public ImageView ivlogo_away;


        public Holder(View itemView) {
            super(itemView);

            tvhome = (TextView) itemView.findViewById(R.id.homeNameTv);
            tvaway = (TextView) itemView.findViewById(R.id.awayNameTv);
            tvhome_skor = (TextView) itemView.findViewById(R.id.homeScoreTv);
            tvaway_skor = (TextView) itemView.findViewById(R.id.awayScoreTv);
            tvtanggal = (TextView) itemView.findViewById(R.id.dateScheduleTv);
            ivlogo_home = (ImageView) itemView.findViewById(R.id.logo_home);
            ivlogo_away = (ImageView) itemView.findViewById(R.id.logo_away);

        }
    }
}
