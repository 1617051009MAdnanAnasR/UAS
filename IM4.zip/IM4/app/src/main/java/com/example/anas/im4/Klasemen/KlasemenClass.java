package com.example.anas.im4.Klasemen;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.anas.im4.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class KlasemenClass extends AppCompatActivity {

    private String urlData = "https://www.thesportsdb.com/api/v1/json/1/lookuptable.php?l=4328&s=1819";

    private RecyclerView recyclerViewHasil;
    private KlasemenAdapter mAdapter;
    private ProgressDialog mProgressDialog;
    private List<KlasemenModel> mListData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klasemen_class);

        recyclerViewHasil = (RecyclerView) findViewById(R.id.recyclerview);

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Loading ...");
        mProgressDialog.show();

        mListData = new ArrayList<>();

        getDataVolley();
    }

    private void getDataVolley(){

        final StringRequest request = new StringRequest(Request.Method.GET, urlData,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mProgressDialog.dismiss();
                        iniData(response);
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void iniData(String response){
        try {
            JSONObject jsonObject = new JSONObject(response);

            JSONArray jsonArray = jsonObject.getJSONArray("table");

            for(int i=0; i<jsonArray.length(); i++){
                JSONObject objectHasil = jsonArray.getJSONObject(i);
                String club = objectHasil.getString("name");
                String play = objectHasil.getString("played");
                String win = objectHasil.getString("win");
                String draw = objectHasil.getString("draw");
                String lose = objectHasil.getString("loss");
                String goals = objectHasil.getString("goalsdifference");
                String poin = objectHasil.getString("total");

                KlasemenModel hasilModel = new KlasemenModel();
                hasilModel.setclub(club);
                hasilModel.setplay(play);
                hasilModel.setwin(win);
                hasilModel.setdraw(draw);
                hasilModel.setlose(lose);
                hasilModel.setgoals(goals);
                hasilModel.setpoin(poin);
                //                hasilModel.setLogo_home(id_home);


                mListData.add(hasilModel);

                mAdapter = new KlasemenAdapter(mListData, KlasemenClass.this);
                mAdapter.notifyDataSetChanged();
                recyclerViewHasil.setLayoutManager(new LinearLayoutManager(KlasemenClass.this));
                recyclerViewHasil.setItemAnimator(new DefaultItemAnimator());
                recyclerViewHasil.setAdapter(mAdapter);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
